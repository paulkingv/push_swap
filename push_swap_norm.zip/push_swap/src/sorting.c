/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sorting.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: paulking <paulking@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/26 15:29:24 by pking             #+#    #+#             */
/*   Updated: 2026/05/23 18:01:59 by pking            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static void	rotate_min_to_top(t_stack *stack)
{
	int	min;
	int	min_i;
	int	i;

	min = stack->a[0];
	min_i = 0;
	i = 1;
	while (i < stack->a_size)
	{
		if (stack->a[i] < min)
		{
			min = stack->a[i];
			min_i = i;
		}
		i++;
	}
	while (min_i-- > 0)
		rotate(stack->a, stack->a_size, "ra");
}

void	sort_three(t_stack *stack)
{
	int	a;
	int	b;
	int	c;

	a = stack->a[0];
	b = stack->a[1];
	c = stack->a[2];
	if (a > b && b < c && a > c)
		rotate(stack->a, stack->a_size, "ra");
	else if (a > b && b > c)
	{
		swap(stack->a, "sa", stack->a_size);
		reverse_rotate(stack->a, stack->a_size, "rra");
	}
	else if (a < b && b > c && a < c)
	{
		swap(stack->a, "sa", stack->a_size);
		rotate(stack->a, stack->a_size, "ra");
	}
	else if (a < b && b > c && a > c)
		reverse_rotate(stack->a, stack->a_size, "rra");
	else if (a > b && b < c && a < c)
		swap(stack->a, "sa", stack->a_size);
}

void	sort_fourfive(t_stack *stack)
{
	if (stack->a_size == 5)
	{
		rotate_min_to_top(stack);
		pb(stack, "pb");
	}
	rotate_min_to_top(stack);
	pb(stack, "pb");
	sort_three(stack);
	while (stack->b_size > 0)
		pa(stack, "pa");
}

void	radix(t_stack *stack)
{
	int	i;
	int	j;
	int	max_bits;
	int	size;

	size = stack->a_size;
	max_bits = 0;
	while ((size - 1) >> max_bits)
		max_bits++;
	i = 0;
	while (i < max_bits)
	{
		j = 0;
		while (j < size)
		{
			if (((stack->a[0] >> i) & 1) == 0)
				pb(stack, "pb");
			else
				rotate(stack->a, stack->a_size, "ra");
			j++;
		}
		while (stack->b_size > 0)
			pa(stack, "pa");
		i++;
	}
}
