/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pking <marvin@d42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/05/23 18:09:38 by pking             #+#    #+#             */
/*   Updated: 2026/05/23 18:10:01 by pking            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include "libft.h"
# include <stdlib.h>
# include <unistd.h>

typedef struct s_stack
{
	int		*a;
	int		*b;
	int		a_size;
	int		b_size;
	char	**args;
}			t_stack;

// Parsing
char		**get_args(char **argv);
int			valid_args(char **args);
int			count_array(char **args);
void		fill_stack(t_stack *stack, char **args);
void		init_stacks(t_stack *stack);
int			is_duplicate(t_stack *stack, int *arr);
int			is_array_sorted(int *arr, int size);

// Indexing
void		index_stack(t_stack *stack);

// Operations
void		swap(int *arr, char *name, int size);
void		rotate(int *arr, int size, char *name);
void		reverse_rotate(int *arr, int size, char *name);
void		pa(t_stack *stack, char *name);
void		pb(t_stack *stack, char *name);

// Sorting
void		sort_three(t_stack *stack);
void		sort_fourfive(t_stack *stack);
void		radix(t_stack *stack);

// Utils
int			error_msg(t_stack *stack);
void		free_all(t_stack *stack);
void		ft_putendl_fd(char *s, int fd);

// Indexing

#endif
